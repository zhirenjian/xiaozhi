const CONFIG_EMPTY = {
  TEST_CONFIG: 'TESET'
}
export default CONFIG_EMPTY
